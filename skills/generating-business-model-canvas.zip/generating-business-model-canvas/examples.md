# Esempi di Utilizzo

Questa guida contiene esempi completi di utilizzo della skill in diversi scenari.

---

## Esempio 1: Brief Completo con Info Sufficienti

**Scenario**: L'utente fornisce un brief completo che contiene tutte le informazioni necessarie per generare il BMC.

```
User: "Genera il Business Model Canvas per il progetto" [allega brief-completo.md]