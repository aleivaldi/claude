Vorrei modificare la skill generating-business-model-canvas perchè crei un file excel che segue il template '/Users/ale/Downloads/business-model-canvas.xlsx' (c'è una skill che consente di leggere e modificare gli excel)

Fai in modo che vengano compilati tutti i fogli del template (ad eccezione di "lean Canvas Example".)

La skill deve:
1) usare la stessa lingua dei documenti in input, a meno che richiesto diversamente dall'utente
2) chiedere all'utente se vuole rispondere alle domande in chat oppure tramite un file 
3) porre tutte le domande che ritiene necessarie per poter compilare il tutto, proponendo risposte e lasciando all'utente di dare la propria
4) creare l'excel secondo le linee guida indicate nell'excel. 

Attenzione che nel template ci sono degli shape che funzionano come post-it. Dato che temo siano troppo complessi iniziamo senza, ma aggungiamo icone per differenziare l'importanza delle affermazioni indicate.

Procederei a step in modo da ridurre il contesto a solo quanto serve per ciasun foglio